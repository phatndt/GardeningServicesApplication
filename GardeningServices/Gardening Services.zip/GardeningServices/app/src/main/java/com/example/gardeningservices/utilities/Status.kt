package com.example.gardeningservices.utilities

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}